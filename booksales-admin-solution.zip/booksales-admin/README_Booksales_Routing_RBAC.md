
# Booksales - Routing & Hak Akses Pengguna (Jawaban Tugas)

Implementasi:
- React Router dengan **Protected Route**.
- **Role-based access**: `admin` vs `user`.
- Session sederhana via `localStorage` (`auth:user`).

## Cara Menjalankan
1. Install dependencies:
   ```bash
   npm install
   ```
2. Jalankan aplikasi:
   ```bash
   npm run dev
   ```

## Alur Akses
- **Publik**: `/` (Home), `/login`.
- **Login diperlukan**: `/profile`.
- **Khusus admin**: `/admin`.
- Belum login dan akses `/profile` atau `/admin` → dialihkan ke `/login` lalu kembali ke halaman asal.

## Lokasi Kode Utama
- `src/auth/AuthContext.jsx` — konteks autentikasi (login/logout, penyimpanan user).
- `src/auth/ProtectedRoute.jsx` — guard route yang memerlukan login.
- `src/auth/RoleRoute.jsx` — guard route untuk role tertentu.
- `src/pages/*` — halaman contoh.
- `src/App.jsx` — definisi semua rute.

## Catatan
- Login tidak memeriksa password (sesuai kebutuhan tugas). Pilih peran `admin` atau `user`.
- Data user disimpan di `localStorage` sebagai `auth:user`.
