
import { Link } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';

export default function Home() {
  const { user, logout } = useAuth();
  return (
    <div style={{ padding: 24 }}>
      <h1>Booksales</h1>
      <p>Selamat datang di Booksales. Ini adalah halaman publik.</p>
      <nav style={{ display: 'flex', gap: 12, marginTop: 12 }}>
        <Link to="/">Home</Link>
        <Link to="/profile">Profile</Link>
        <Link to="/admin">Admin Dashboard</Link>
        {!user && <Link to="/login">Login</Link>}
      </nav>
      {user ? (
        <div style={{ marginTop: 16 }}>
          <p>Login sebagai: <b>{user.username}</b> ({user.role})</p>
          <button onClick={logout}>Logout</button>
        </div>
      ) : (
        <p style={{ marginTop: 16 }}>Kamu belum login.</p>
      )}
    </div>
  );
}
