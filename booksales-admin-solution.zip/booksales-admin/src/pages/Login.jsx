
import { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';

export default function Login() {
  const [username, setUsername] = useState('admin');
  const [role, setRole] = useState('admin'); // 'admin' | 'user'
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const from = location.state?.from?.pathname || '/';

  const handleSubmit = (e) => {
    e.preventDefault();
    login(username.trim() || 'guest', role);
    navigate(from, { replace: true });
  };

  return (
    <div style={{ padding: 24 }}>
      <h2>Login</h2>
      <form onSubmit={handleSubmit} style={{ display: 'grid', gap: 12, maxWidth: 360 }}>
        <label>
          Username
          <input value={username} onChange={(e) => setUsername(e.target.value)} placeholder="nama pengguna" />
        </label>
        <label>
          Peran
          <select value={role} onChange={(e) => setRole(e.target.value)}>
            <option value="admin">admin</option>
            <option value="user">user</option>
          </select>
        </label>
        <button type="submit">Masuk</button>
      </form>
      <p style={{ marginTop: 16 }}>
        Setelah login, kamu akan diarahkan ke halaman yang kamu minta sebelumnya.
      </p>
    </div>
  );
}
