
import { useAuth } from '../auth/AuthContext';

export default function Profile() {
  const { user } = useAuth();
  return (
    <div style={{ padding: 24 }}>
      <h2>Profil Pengguna</h2>
      <p>Nama pengguna: <b>{user?.username}</b></p>
      <p>Peran: <b>{user?.role}</b></p>
    </div>
  );
}
