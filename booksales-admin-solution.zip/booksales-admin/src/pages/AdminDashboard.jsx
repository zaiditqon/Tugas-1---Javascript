
export default function AdminDashboard() {
  return (
    <div style={{ padding: 24 }}>
      <h2>Dashboard Admin</h2>
      <ul>
        <li>Kelola Buku</li>
        <li>Kelola Transaksi</li>
        <li>Laporan Penjualan</li>
      </ul>
      <p>Halaman ini hanya dapat diakses oleh <b>admin</b>.</p>
    </div>
  );
}
