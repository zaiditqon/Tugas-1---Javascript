const books = [
  {
    id: 1,
    title: "Belajar JavaScript Dasar",
    author: "Andi Prasetyo",
    year: 2021,
    description: "Panduan lengkap untuk pemula yang ingin belajar JavaScript dari nol.",
    image: "https://images.unsplash.com/photo-1519681393784-d120267933ba?q=80&w=1200&auto=format&fit=crop"
  },
  {
    id: 2,
    title: "React untuk Pemula",
    author: "Dina Sari",
    year: 2022,
    description: "Konsep dan praktik membuat aplikasi React modern.",
    image: "https://images.unsplash.com/photo-1521587760476-6c12a4b040da?q=80&w=1200&auto=format&fit=crop"
  },
  {
    id: 3,
    title: "TypeScript: Jalan Ninja",
    author: "Bagus W.",
    year: 2023,
    description: "Menulis kode lebih aman dan terprediksi dengan TypeScript.",
    image: "https://images.unsplash.com/photo-1495446815901-a7297e633e8d?q=80&w=1200&auto=format&fit=crop"
  },
  {
    id: 4,
    title: "Node.js Praktis",
    author: "Rudi Putra",
    year: 2020,
    description: "Membangun API cepat dengan Express dan ekosistem Node.",
    image: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?q=80&w=1200&auto=format&fit=crop"
  },
  {
    id: 5,
    title: "UI/UX untuk Dev",
    author: "Sari Dewi",
    year: 2019,
    description: "Dasar desain antarmuka yang ramah pengguna untuk developer.",
    image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?q=80&w=1200&auto=format&fit=crop"
  },
  {
    id: 6,
    title: "Database Modern",
    author: "Akbar Ramadhan",
    year: 2021,
    description: "Relasional vs NoSQL, kapan memilih yang mana.",
    image: "https://images.unsplash.com/photo-1518779578993-ec3579fee39f?q=80&w=1200&auto=format&fit=crop"
  },
  {
    id: 7,
    title: "Git Lebih Dalam",
    author: "Intan N.",
    year: 2018,
    description: "Alur kerja branch, rebase vs merge, dan praktik rapi.",
    image: "https://images.unsplash.com/photo-1524995997946-a1c2e315a42f?q=80&w=1200&auto=format&fit=crop"
  },
  {
    id: 8,
    title: "Clean Code Indonesia",
    author: "Rahmat H.",
    year: 2020,
    description: "Prinsip menulis kode yang mudah dibaca dan dirawat.",
    image: "https://images.unsplash.com/photo-1515879218367-8466d910aaa4?q=80&w=1200&auto=format&fit=crop"
  },
  {
    id: 9,
    title: "Algoritma untuk Semua",
    author: "Yuni K.",
    year: 2024,
    description: "Cara berpikir algoritmik dan pola pemecahan masalah.",
    image: "https://images.unsplash.com/photo-1453738773917-9c3eff1db985?q=80&w=1200&auto=format&fit=crop"
  }
]

export default books
