import books from '../Utils/books.js'
import BookCard from '../components/BookCard.jsx'

export default function Home() {
  return (
    <div>
      <div className="header">
        <h1>Daftar Buku</h1>
      </div>
      <div className="grid">
        {books.map((b) => <BookCard key={b.id} book={b} />)}
      </div>
    </div>
  )
}
