import { useMemo, useState } from 'react'
import initialBooks from '../Utils/books.js'
import BookCard from '../components/BookCard.jsx'

export default function Book() {
  const [books, setBooks] = useState(initialBooks)
  const [form, setForm] = useState({ title:'', author:'', year:'', description:'', image:'' })
  const [query, setQuery] = useState('')

  const filtered = useMemo(() => {
    const q = query.toLowerCase()
    return books.filter(b =>
      b.title.toLowerCase().includes(q) ||
      b.author.toLowerCase().includes(q)
    )
  }, [books, query])

  const handleChange = (e) => {
    const { name, value } = e.target
    setForm(prev => ({ ...prev, [name]: value }))
  }

  const addBook = () => {
    if (!form.title || !form.author) return alert('Judul & Penulis wajib diisi')
    const id = books.length ? Math.max(...books.map(b=>b.id)) + 1 : 1
    const year = Number(form.year) || new Date().getFullYear()
    setBooks(prev => [...prev, { id, ...form, year }])
    setForm({ title:'', author:'', year:'', description:'', image:'' })
  }

  return (
    <div>
      <div className="header">
        <h1>Kelola Buku</h1>
        <input className="input" placeholder="Cari judul/penulis..." value={query} onChange={e=>setQuery(e.target.value)} style={{maxWidth: 260}}/>
      </div>

      <div className="form">
        <input className="input span-3" name="title" placeholder="Judul *" value={form.title} onChange={handleChange} />
        <input className="input span-3" name="author" placeholder="Penulis *" value={form.author} onChange={handleChange} />
        <input className="input span-2" name="year" placeholder="Tahun" value={form.year} onChange={handleChange} />
        <input className="input span-4" name="image" placeholder="URL Gambar (opsional)" value={form.image} onChange={handleChange} />
        <textarea className="textarea span-6" name="description" placeholder="Deskripsi singkat" rows={3} value={form.description} onChange={handleChange} />
      </div>
      <div style={{marginTop: 10, marginBottom: 22}}>
        <button className="button" onClick={addBook}>Tambah Buku</button>
      </div>

      <div className="grid">
        {filtered.map((b) => <BookCard key={b.id} book={b} />)}
      </div>
    </div>
  )
}
