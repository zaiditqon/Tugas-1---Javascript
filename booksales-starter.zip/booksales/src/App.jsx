import { NavLink, Route, Routes } from 'react-router-dom'
import Home from './pages/Home.jsx'
import Book from './pages/Book.jsx'

export default function App() {
  return (
    <div className="container">
      <nav className="nav">
        <NavLink to="/" end>Home</NavLink>
        <NavLink to="/book">Book</NavLink>
        <a href="https://github.com/" target="_blank" rel="noreferrer">GitHub</a>
      </nav>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/book" element={<Book />} />
      </Routes>
      <hr />
      <p className="small">Starter by ChatGPT • React + Vite + React Router</p>
    </div>
  )
}
