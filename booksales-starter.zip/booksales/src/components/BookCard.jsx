export default function BookCard({ book }) {
  return (
    <div className="card">
      <img src={book.image} alt={book.title} onError={(e)=>{e.currentTarget.src='https://picsum.photos/seed/book'+book.id+'/640/360'}}/>
      <div className="body">
        <div className="badge">{book.author} • {book.year}</div>
        <h3 style={{margin: '6px 0 4px'}}>{book.title}</h3>
        <p style={{opacity:.9, lineHeight:1.4}}>{book.description}</p>
      </div>
    </div>
  )
}
