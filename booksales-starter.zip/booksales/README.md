# BookSales (Starter)
Starter kecil untuk tugas React dasar: data buku, render di Home & Book, tambah data pakai hooks.

## Fitur
- Data awal 9 buku di `src/Utils/books.js`
- Halaman **Home** (list buku) dan **Book** (kelola + tambah buku)
- Pencarian (client-side) dan kartu buku reusable
- React Router sudah siap

## Cara Menjalankan
```bash
npm install
npm run dev
```
Lalu buka URL yang tampil di terminal.

## Struktur
```
src/
  App.jsx
  main.jsx
  styles.css
  Utils/books.js
  components/BookCard.jsx
  pages/
    Home.jsx
    Book.jsx
```
Silakan modifikasi data & gaya sesuai kebutuhan tugas (repo GitHub, undang mentor, unggah link ke LMS).
