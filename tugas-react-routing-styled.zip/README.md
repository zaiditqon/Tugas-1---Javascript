# Tugas — React Router + Styling

## Jalankan
npm install
npm run dev

## Rute
/ -> Home
/team -> Team
/contact -> Contact

## Catatan
- Layout terpisah (`layout/DefaultLayout.jsx`).
- Navbar menggunakan NavLink + active styling.
