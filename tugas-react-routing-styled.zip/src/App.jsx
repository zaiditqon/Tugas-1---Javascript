import { Routes, Route } from 'react-router-dom'
import DefaultLayout from './layout/DefaultLayout'
import Home from './components/Home'
import Team from './components/Team'
import Contact from './components/Contact'
export default function App(){return(<Routes><Route element={<DefaultLayout/>}><Route path='/' element={<Home/>}/><Route path='/team' element={<Team/>}/><Route path='/contact' element={<Contact/>}/></Route></Routes>)}