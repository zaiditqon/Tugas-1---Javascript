import Navbar from './components/Navbar.jsx'
import Home from './components/Home.jsx'
import Team from './components/Team.jsx'
import Contact from './components/Contact.jsx'

export default function App() {
  return (
    <>
      <Navbar />
      <main>
        <Home />
        <Team />
        <Contact />
      </main>
      <footer className="py-4 border-top text-center">
        <small className="text-muted">© {new Date().getFullYear()} NF Academy</small>
      </footer>
    </>
  );
}
