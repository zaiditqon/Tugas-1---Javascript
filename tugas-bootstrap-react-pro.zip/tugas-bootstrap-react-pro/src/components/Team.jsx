export default function Team() {
  const members = [
    { name: "Alice", role: "Frontend Developer", desc: "Suka React & UX." },
    { name: "Bob", role: "UI Designer", desc: "Fokus tipografi & layout." },
    { name: "Charlie", role: "Fullstack", desc: "API & integrasi." },
  ];

  return (
    <section id="team" className="py-5">
      <div className="container">
        <div className="text-center mb-5">
          <h2 className="fw-bold">Tim Kami</h2>
          <p className="text-secondary">Silakan ganti nama, role, dan foto.</p>
        </div>
        <div className="row g-4">
          {members.map((m, i) => (
            <div className="col-md-4" key={i}>
              <div className="card h-100 text-center">
                <div className="ratio ratio-1x1 bg-light"></div>
                <div className="card-body">
                  <h5 className="card-title mb-0">{m.name}</h5>
                  <div className="text-muted">{m.role}</div>
                  <p className="small mt-2">{m.desc}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
