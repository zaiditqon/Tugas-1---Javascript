export default function Home() {
  return (
    <header id="home" className="py-5 bg-light border-bottom">
      <div className="container py-5">
        <div className="row align-items-center g-4">
          <div className="col-lg-6">
            <h1 className="display-5 fw-bold">Selamat datang di NF Academy</h1>
            <p className="lead">Tugas: rapihkan Home, lengkapi Team & Contact (React + Bootstrap).</p>
            <a href="#team" className="btn btn-primary btn-lg">Lihat Tim</a>
          </div>
          <div className="col-lg-6">
            <div className="ratio ratio-16x9 rounded-4 overflow-hidden shadow-sm bg-light"></div>
          </div>
        </div>
      </div>
    </header>
  );
}
