export default function Contact() {
  const handleSubmit = (e) => {
    e.preventDefault();
    const form = e.currentTarget;
    if (!form.checkValidity()) { e.stopPropagation(); }
    else { alert('Pesan terkirim (simulasi)!'); }
    form.classList.add('was-validated');
  };

  return (
    <section id="contact" className="py-5">
      <div className="container">
        <div className="row g-4">
          <div className="col-lg-6">
            <h2 className="fw-bold mb-3">Hubungi Kami</h2>
            <p className="text-secondary">Sampaikan pesan/masukan melalui form berikut.</p>
            <form className="needs-validation" noValidate onSubmit={handleSubmit}>
              <div className="mb-3">
                <label className="form-label">Nama</label>
                <input type="text" className="form-control" required />
                <div className="invalid-feedback">Nama wajib diisi.</div>
              </div>
              <div className="mb-3">
                <label className="form-label">Email</label>
                <input type="email" className="form-control" required />
                <div className="invalid-feedback">Email tidak valid.</div>
              </div>
              <div className="mb-3">
                <label className="form-label">Pesan</label>
                <textarea className="form-control" rows="5" required></textarea>
                <div className="invalid-feedback">Pesan wajib diisi.</div>
              </div>
              <button className="btn btn-primary" type="submit">Kirim</button>
            </form>
          </div>
          <div className="col-lg-6">
            <div className="card h-100">
              <div className="card-body">
                <h5 className="card-title">Informasi</h5>
                <ul className="list-unstyled mb-0">
                  <li><strong>Alamat:</strong> Jl. Contoh No. 123</li>
                  <li><strong>Telepon:</strong> 0812-3456-7890</li>
                  <li><strong>Email:</strong> halo@nfacademy.test</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
